def divide_numbers(a, b):
    return a / b

num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))

result = divide_numbers(num1, num2)
print("Result:", result)