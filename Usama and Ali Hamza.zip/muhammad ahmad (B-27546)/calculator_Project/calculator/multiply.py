# multiply.py
# This module contains a function to multiply two numbers.

def multiply(a, b):
    """Return the product of two numbers."""
    return a * b