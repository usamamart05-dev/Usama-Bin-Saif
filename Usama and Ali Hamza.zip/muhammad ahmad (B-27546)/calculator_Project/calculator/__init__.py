# __init__.py
# This file makes the 'calculator' folder a Python package.
# It can also be used to initialize or import module-level functionality.