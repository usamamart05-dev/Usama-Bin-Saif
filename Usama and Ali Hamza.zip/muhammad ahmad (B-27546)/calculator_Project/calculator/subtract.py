# subtract.py
# This module contains a function to subtract two numbers.

def subtract(a, b):
    """Return the difference of two numbers."""
    return a - b