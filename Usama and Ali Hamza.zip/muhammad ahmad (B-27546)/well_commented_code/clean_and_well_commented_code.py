"""
Program: Display Student Information
Objective: Demonstrate clean coding by using consistent formatting and comments.
"""

# Printing student information
print("Name: Ahmad")
print("Age: 20")
print("Department: BSCS")
print("University: University of South Asia")