print("Name:ahmad")
print("Age:",20)
print("department","BSCS")
print("University of south asia")